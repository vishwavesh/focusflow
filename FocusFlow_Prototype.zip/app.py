import streamlit as st
import psutil
import datetime
import time

st.set_page_config(page_title="FocusFlow — Local Context Layer", layout="wide", page_icon="⚡")

# Top Header
st.title("⚡ FocusFlow — Local AI Context Layer")
st.caption("Snapdragon NPU-Accelerated Local Agent | Active Device: Snapdragon X Elite")

# Sidebar - Architecture & Status
with st.sidebar:
    st.subheader("Hardware & Runtime")
    st.success("● Qualcomm NPU Active (Simulated)")
    st.info("Inference: Local Quantized VLM + Whisper STT")
    st.markdown("---")
    st.subheader("Privacy Engine")
    privacy_mode = st.toggle("ScreenGuard Redaction", value=True)
    st.caption("Automatically masks API keys, emails, and banking windows.")

# Tabs for Core Pillars
tab1, tab2, tab3, tab4 = st.tabs([
    "🕒 Recent Context", 
    "⚡ Ask Mode (Ctrl+Space)", 
    "🔴 Context Session", 
    "🗃️ Memory Engine"
])

# Tab 1: Recent Context / Continue Where You Left Off
with tab1:
    st.subheader("Continue Where You Left Off")
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        **💻 Development Session**  
        *App: VS Code* | *Duration: 1h 42m*  
        - Debugged local API integration route  
        - **Last State:** Request body validation  
        - **Next Action:** Verify ONNX / NPU runtime execution
        """)
        if st.button("Resume VS Code Context"):
            st.success("Context restored to active working memory.")

    with col2:
        st.markdown("""
        **📚 Research Session**  
        *App: Chrome & PDF* | *Duration: 55m*  
        - Topic: Local LLM Quantization & Context Windows  
        - **Key Finding:** INT4 weight-only quantization maintains accuracy on NPU  
        - **Unresolved:** Memory footprint limits during audio STT concurrency
        """)
        if st.button("View Research Digest"):
            st.info("Opening session context summary...")

# Tab 2: Ask Mode
with tab2:
    st.subheader("Ask Mode — Fast Screen Inspection")
    uploaded_file = st.file_uploader("Drop a screen capture or test image", type=["png", "jpg", "jpeg"])
    prompt = st.text_input("Ask a question about this screen:", placeholder="Explain the error or summarize this view...")
    
    if st.button("Analyze with Local Vision Model"):
        if uploaded_file or prompt:
            with st.spinner("Processing through local NPU pipeline..."):
                time.sleep(1.2)
            st.success("Inference Complete (18ms on NPU)")
            st.markdown(f"**FocusFlow Agent:** Found relevant context for `{prompt}`. The screen shows active development processes; recommended next step is updating local route parameters.")
        else:
            st.warning("Please provide an image or question.")

# Tab 3: Continuous Context Session
with tab3:
    st.subheader("Continuous Session Controller")
    st.write("Grant scoped, continuous perception for meetings, deep work, or research.")
    
    col_a, col_b = st.columns(2)
    with col_a:
        session_type = st.selectbox("Session Type", ["Research Session", "Meeting Mode", "Deep Focus"])
        allow_screen = st.checkbox("Allow Screen / OCR", value=True)
        allow_mic = st.checkbox("Allow Microphone (Live STT)", value=True)
    
    with col_b:
        running_apps = ['VS Code', 'Chrome', 'Zoom', 'Spotify', 'Terminal']
        selected_apps = st.multiselect("Active Applications to Track", running_apps, default=running_apps[:3])

    if st.button("Start Context Session"):
        st.success(f"Session started for {session_type}. Tracking {len(selected_apps)} apps.")
        st.write("● Recording state to ephemeral local session cache...")

# Tab 4: Structured Memory
with tab4:
    st.subheader("Structured Knowledge Vault")
    st.markdown("""
    | Timestamp | Category | Extracted Structured Context | Persistence |
    |---|---|---|---|
    | Today, 14:15 | Architecture | Snapdragon NPU handles speech STT & vision pipeline | Encrypted DB |
    | Today, 11:30 | Meeting | Target benchmark: Sub-25ms latency for screen OCR | Encrypted DB |
    | Yesterday | Debugging | Local models stored under `~/.focusflow/weights` | Session Cache |
    """)
    if st.button("Export Memory to JSON"):
        st.download_button("Download Encrypted Export", data='{"project":"FocusFlow","status":"verified"}', file_name="focusflow_memory.json")
