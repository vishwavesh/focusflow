# FocusFlow: Your Private AI Layer for Your PC
> Submitted for the Snapdragon Hackathon | Vishwavesh Pandey

FocusFlow is a local-first, multimodal personal AI agent that maintains continuous context across your desktop workflow. Powered by on-device NPU acceleration, it provides on-demand assistance, active session memory, and intelligent task resumption without transmitting private data to cloud servers.

---

## ⚡ Quickstart (Run the Prototype)

Clone the repository and launch the local prototype dashboard:

```bash
pip install -r requirements.txt
streamlit run app.py
```

---

## 🧠 Core Architecture

```
                 USER WORKSPACE
                       │
          ┌────────────┼────────────┐
          ▼            ▼            ▼
        SCREEN        AUDIO       ACTIVITY
        (Vision)      (STT)      (Window/App)
          │            │            │
          └────────────┼────────────┘
                       ▼
             LOCAL CONTEXT ENGINE
                       ▼
          QUALCOMM SNAPDRAGON NPU
        (Low-power local inference)
                       ▼
             STRUCTURED MEMORY DB
```

### 1. Ask Mode (`Ctrl + Space`)
Instant visual & OCR debugging directly on the active viewport.

### 2. Context Sessions
Targeted, permission-gated tracking for deep research, coding sessions, or meetings with live transcription and translation.

### 3. Recent Context & Long-Term Memory
Distinguishes short-term session state from encrypted long-term semantic project memory.

---

## 🛠️ Hardware Acceleration
- **Target Device:** Snapdragon X Series PC
- **Acceleration Pipeline:** Qualcomm AI Hub optimized ONNX models targeting NPU for vision embedding and local language processing.
- **Privacy Engine:** Automatic local ScreenGuard redacts sensitive tokens, passwords, and banking apps before context extraction.
